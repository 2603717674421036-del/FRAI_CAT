"""LLM client: sends ONE job post to the LLM and returns its raw text reply.

The API key is read from the environment (or a local .env file), never from code.
Only the post text is ever sent. Student data never reaches this file.
"""
import json
import os
import re
import urllib.request

PROMPT_FILE = "system_prompt.txt"


def load_env(path=".env"):
    """Read KEY=VALUE lines from .env into os.environ (no extra libraries needed)."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.split("#")[0].strip()      # drop comments
            if "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())


def load_prompt():
    """Read the system prompt from its own text file."""
    with open(PROMPT_FILE, encoding="utf-8") as f:
        return f.read()


def _post_json(url, headers, body):
    """Send a JSON POST request and return the parsed JSON reply (30 s timeout)."""
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _call_gemini(system_prompt, post, key, model):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {"system_instruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"parts": [{"text": f"<post>{post}</post>"}]}],
            "generationConfig": {"temperature": 0, "responseMimeType": "application/json"}}
    data = _post_json(url, {"x-goog-api-key": key}, body)
    return data["candidates"][0]["content"]["parts"][0]["text"]


def _call_anthropic(system_prompt, post, key, model):
    body = {"model": model, "max_tokens": 300, "temperature": 0, "system": system_prompt,
            "messages": [{"role": "user", "content": f"<post>{post}</post>"}]}
    data = _post_json("https://api.anthropic.com/v1/messages",
                      {"x-api-key": key, "anthropic-version": "2023-06-01"}, body)
    return data["content"][0]["text"]


def _call_mock(post):
    """OFFLINE TESTING ONLY. A deliberately careless fake 'LLM' so the Python
    checks can be tested without an API key. It makes the mistakes a real LLM
    can make (converts percentages, guesses branches, adds extra fields)."""
    p = post.lower()
    branches = []
    for name, pattern in [("CSE", r"\bcse\b"), ("IT", r"\bit\b"), ("AIDS", r"ai&ds|aids"),
                          ("ECE", r"\bece\b"), ("EEE", r"\beee\b"),
                          ("MECH", r"mechanical|\bmech\b"), ("CIVIL", r"civil")]:
        if re.search(pattern, p):
            branches.append(name)
    if re.search(r"any branch|all branches", p):
        branches = ["ALL"]
    if not branches and "engineering students" in p:
        branches = ["CSE", "IT"]                       # careless guess from the job role
    cgpa = None
    m = re.search(r"cgpa\D{0,12}(\d+(?:\.\d+)?)|(\d+(?:\.\d+)?)\s*(?:\+|cgpa)", p)
    if m:
        cgpa = float(m.group(1) or m.group(2))
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:percent|%)", p)
    if m:                                              # careless: converts percentage
        cgpa = float(m.group(1)) / 10 if float(m.group(1)) > 10 else 9.0
    backlogs = None
    if re.search(r"(no|not allowed)\b.*(backlog|arrear)|(backlog|arrear)s? not allowed", p):
        backlogs = 0
    m = re.search(r"up to (\d+) backlog", p)
    if m:
        backlogs = int(m.group(1))
    m = re.search(r"\b(20\d\d)\b", p)
    reply = {"branches": branches, "min_cgpa": cgpa, "max_backlogs": backlogs,
             "batch": int(m.group(1)) if m else None, "summary": post[:60]}
    if "add student" in p or "add a student" in p:
        reply["students"] = ["27CS999 Test User"]      # careless: obeys the post
    return json.dumps(reply)


def call_llm(post):
    """Send one post to the chosen provider and return the raw text reply."""
    load_env()
    provider = os.environ.get("LLM_PROVIDER", "gemini").lower()
    if provider == "mock":
        return _call_mock(post)
    key = os.environ.get("LLM_API_KEY")
    if not key:
        raise RuntimeError("LLM_API_KEY is not set (see .env.example)")
    prompt = load_prompt()
    if provider == "anthropic":
        return _call_anthropic(prompt, post, key, os.environ.get("LLM_MODEL") or "claude-haiku-5-5")
    return _call_gemini(prompt, post, key, os.environ.get("LLM_MODEL") or "gemini-2.5-flash")
